# DarkFB Termux

<ul>
<li><code>pkg install git python2 coreutils nano</code></li>
<li><code>pip2 install --upgrade pip</code></li>
<li><code>git clone https://github.com/JeelsBoobz/DarkFB</code></li>
<li><code>cd DarkFB</code></li>
<li><code>pip2 install -r requirements.txt</code></li>
<li><code>python2 DarkFB.py</code></li>
</ul>
<br />
<b><u>Catatan</u> :</b><br />
<ul>
<li>Jikan ingin menambahkan list password edit dengan command:<br />
<code>nano password.bin</code></li>
<li>Jika merasa ada log ya bypass saja langsung pakai tokenmu dengan command:<br />
<code>echo "TOKENMU" > login.txt</code></li>
</ul>
<br />
<img src="https://github.com/JeelsBoobz/DarkFB/raw/master/Screenshot_2019-07-05-13-51-45-078_com.termux.png" />
